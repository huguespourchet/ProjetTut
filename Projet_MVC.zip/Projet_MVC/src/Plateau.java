public class Plateau {


    public Plateau(){
        super();
    }
}
