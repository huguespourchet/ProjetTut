public class ControlGroup {

    private Plateau plateau;
    private Fenetre fenetre;
    public ControlBouton controlButton;
    public ControlMenu controlMenu;


    public ControlGroup(Plateau plateau) {

        this.plateau = plateau;
        this.fenetre = new Fenetre(plateau);

        this.controlButton = new ControlBouton(plateau,fenetre);
        this.controlMenu = new ControlMenu(fenetre);

        fenetre.display();
    }
}